from __future__ import annotations

from typing import Self

from httpx import BasicAuth, Headers, Timeout
from yarl import URL

from .utils import is_http_url


class BasePostgrestClient:
    """Base PostgREST client."""

    def __init__(
        self,
        base_url: URL,
        *,
        schema: str,
        headers: dict[str, str],
        timeout: int | float | Timeout,
        verify: bool = True,
        proxy: str | None = None,
    ) -> None:
        if not is_http_url(base_url):
            raise ValueError("base_url must be a valid HTTP URL string")

        self.base_url = base_url
        self.headers = Headers(headers)
        self.headers["Accept-Profile"] = schema
        self.headers["Content-Profile"] = schema
        self.timeout = timeout
        self.verify = verify
        self.proxy = proxy
        self.basic_auth: BasicAuth | None = None

    def auth(
        self,
        token: str | None,
        *,
        username: str | bytes | None = None,
        password: str | bytes = "",
    ) -> Self:
        """
        Authenticate the client with either bearer token or basic authentication.

        Raises:
            `ValueError`: If neither authentication scheme is provided.

        .. note::
            Bearer token is preferred if both ones are provided.
        """
        if token:
            self.basic_auth = None
            self.headers["Authorization"] = f"Bearer {token}"
        elif username:
            self.basic_auth = BasicAuth(username, password)
        else:
            raise ValueError(
                "Neither bearer token or basic authentication scheme is provided"
            )
        return self
